# SdFileExplorer icons

Original compact icon set for a generic Angular file explorer. Assets have a
transparent canvas. No external font, bitmap, stylesheet, or CDN dependency.

## Files

- `svg/*.svg`: 64 × 64 viewBox; use these by default at any UI size.
- `png/32/*.png`: 32 × 32 transparent fallback (1× for a 32 px slot).
- `png/64/*.png`: 64 × 64 transparent fallback (2× for a 32 px slot).
- `file-icon-map.ts`: optional, framework-independent filename/MIME resolver.
- `manifest.json`: format-to-icon mapping and metadata.

Example for a list row with an adjacent visible filename:

```html
<img src="assets/file-explorer-icons/svg/file-pdf.svg" width="32" height="32" alt="" />
```

If PNG is required, use `png/32` for 1× and `png/64` in `srcset` for 2×.
There is one generic file fallback (`file-generic`) plus folder open/closed and
family-level fallbacks. The resolver checks compound suffixes before MIME.
Store the assets in the Angular library's established public asset location;
adjust the URL prefix to its packaging convention. Avoid importing the entire
folder eagerly if only a subset is used.

SVG was kept as the source of truth. PNG files were rasterized from those SVGs.
Use the host's existing accessible filename label; keep each icon decorative
with `alt=""` when next to that label. Avoid styling the SVG fill with CSS: the
assets use stable file-family colors and work on light and dark surfaces.
